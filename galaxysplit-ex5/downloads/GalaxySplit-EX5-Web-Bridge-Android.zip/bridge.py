"""Local ADB bridge for GalaxySplit EX5 Test. Python 3.9+, no third-party modules."""
import argparse
import hashlib
import hmac
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


def operation_command(operations, name, args):
    if name not in operations or not isinstance(args, dict):
        raise ValueError('Неизвестная операция')
    spec = operations[name]
    parameters = spec.get('parameters', {})
    if set(parameters) != set(args):
        raise ValueError('Неверные параметры операции')
    command = spec['command']
    for key, pattern in parameters.items():
        value = str(args[key])
        if not re.fullmatch(pattern, value):
            raise ValueError('Неверный параметр: ' + key)
        command = command.replace('{' + key + '}', value)
    return command


def adb_address(value):
    match = re.fullmatch(r'(\d{1,3}(?:\.\d{1,3}){3}):(\d{1,5})', value)
    if not match:
        raise ValueError('Введите IP и порт ADB, например 192.168.1.10:5555')
    ip = ipaddress.ip_address(match[1])
    if not (ip.is_private or ip.is_loopback) or not 1 <= int(match[2]) <= 65535:
        raise ValueError('Нужен адрес ГУ в локальной сети и допустимый порт')
    return value


class Bridge:
    def __init__(self, root, adb):
        self.root = Path(root).resolve()
        self.adb = str(adb)
        self.token = secrets.token_urlsafe(32)
        self.serial = None
        self.lock = threading.RLock()
        self.operations = json.loads((self.root / 'operations.json').read_text('utf-8'))
        self.manifest = json.loads((self.root / 'assets/manifest.json').read_text('utf-8'))

    def run(self, args, timeout=50, input_text=None, selected=True):
        if selected and not self.serial:
            raise ValueError('Сначала подключите ГУ')
        prefix = [self.adb] + (['-s', self.serial] if selected else [])
        try:
            result = subprocess.run(prefix + args, input=input_text, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True, encoding='utf-8', errors='replace',
                                    timeout=timeout, creationflags=0x08000000 if os.name == 'nt' else 0)
        except subprocess.TimeoutExpired:
            raise ValueError('ADB не ответил вовремя. Проверьте соединение с ГУ.') from None
        if result.returncode:
            raise ValueError((result.stderr or result.stdout or 'Ошибка ADB')[:1500].strip())
        return result.stdout.strip()

    def connect(self, address):
        with self.lock:
            if address:
                address = adb_address(address)
                output = self.run(['connect', address], selected=False)
                if not re.search(r'(connected to|already connected)', output):
                    raise ValueError(output or 'ADB не подключился')
                self.serial = address
            else:
                output = self.run(['devices'], selected=False)
                devices = re.findall(r'^(\S+)\s+device\s*$', output, re.M)
                if len(devices) != 1:
                    raise ValueError('Подключите одно ГУ по USB и подтвердите отладку. Либо укажите IP и порт для Wi-Fi.')
                self.serial = devices[0]
            sdk = self.op('sdk', {})
            if sdk != '30':
                self.serial = None
                raise ValueError('Тест предназначен только для Android 11 / API 30. Получено: ' + sdk)

    def op(self, name, args):
        with self.lock:
            return self.run(['shell', operation_command(self.operations, name, args)])

    def push(self, data):
        expected = self.manifest['apk']
        if len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != expected['sha256']:
            raise ValueError('Контрольная сумма APK не совпала')
        with self.lock, tempfile.TemporaryDirectory(prefix='galaxysplit-ex5-') as directory:
            file = Path(directory) / 'test.apk'
            file.write_bytes(data)
            self.run(['push', str(file), '/data/local/tmp/galaxysplit-ex5-test.apk'])


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(args[2].bridge.root), **kwargs)

    def log_message(self, format, *args):
        pass  # Requests can contain local authentication data; don't log URLs or bodies.

    def valid_host(self):
        port = self.server.server_address[1]
        allowed = {f'127.0.0.1:{port}', f'localhost:{port}'}
        return self.headers.get('Host') in allowed and self.headers.get('Origin', f'http://127.0.0.1:{port}') in {'http://' + host for host in allowed}

    def authenticated(self):
        return self.valid_host() and hmac.compare_digest(self.headers.get('X-Galaxy-Token', ''), self.server.bridge.token)

    def json_response(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.valid_host():
            self.json_response({'ok': False, 'error': 'Недопустимый адрес запроса'}, 403)
            return
        if urlsplit(self.path).path.startswith('/api/'):
            if not self.authenticated():
                self.json_response({'ok': False, 'error': 'Перезапустите мост и откройте страницу из него'}, 403)
            elif self.path == '/api/ping':
                self.json_response({'ok': True})
            else:
                self.json_response({'ok': False, 'error': 'Неизвестный запрос'}, 404)
            return
        super().do_GET()

    def do_POST(self):
        if not self.authenticated():
            self.json_response({'ok': False, 'error': 'Недопустимый запрос к мосту'}, 403)
            return
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size < 0 or size > 1024 * 1024:
                raise ValueError('Слишком большой запрос')
            body = self.rfile.read(size)
            if len(body) != size:
                raise ValueError('Неполный запрос')
            bridge = self.server.bridge
            if self.path == '/api/push':
                bridge.push(body)
                self.json_response({'ok': True})
                return
            data = json.loads(body)
            if self.path == '/api/connect':
                bridge.connect(str(data.get('address', '')).strip())
                self.json_response({'ok': True})
            elif self.path == '/api/pair':
                address = adb_address(str(data.get('address', '')).strip())
                code = str(data.get('code', '')).strip()
                if not re.fullmatch(r'\d{6}', code):
                    raise ValueError('Нужен шестизначный код сопряжения')
                with bridge.lock:
                    result = bridge.run(['pair', address], input_text=code + '\n', selected=False)
                if 'Successfully paired' not in result:
                    raise ValueError('Не удалось выполнить сопряжение. Проверьте код и порт.')
                self.json_response({'ok': True})
            elif self.path == '/api/op':
                output = bridge.op(data.get('name'), data.get('args', {}))
                self.json_response({'ok': True, 'stdout': output})
            else:
                self.json_response({'ok': False, 'error': 'Неизвестный запрос'}, 404)
        except Exception as error:
            safe_message = re.sub(r'\b[a-f0-9]{64}\b', '[ключ скрыт]', str(error))
            self.json_response({'ok': False, 'error': safe_message[:1800]}, 400)


def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=str(root / 'web'))
    parser.add_argument('--adb', default=str(root / 'tools/adb.exe') if os.name == 'nt' else shutil.which('adb'))
    parser.add_argument('--port', type=int, default=8769)
    parser.add_argument('--no-browser', action='store_true')
    options = parser.parse_args()
    if not options.adb or not Path(options.adb).is_file():
        raise SystemExit('ADB не найден. Распакуйте весь архив. На Android установите android-tools в Termux.')
    server = ThreadingHTTPServer(('127.0.0.1', options.port), Handler)
    server.bridge = Bridge(options.root, options.adb)
    url = f'http://127.0.0.1:{server.server_address[1]}/#bridge={server.bridge.token}'
    print('GalaxySplit EX5: local installer started. Close this window after testing.', flush=True)
    if not options.no_browser:
        webbrowser.open(url)
    else:
        print(url, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
