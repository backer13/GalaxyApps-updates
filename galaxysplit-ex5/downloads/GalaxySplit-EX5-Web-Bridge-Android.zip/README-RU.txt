﻿Нужен Termux, Python и android-tools:
pkg install python android-tools unzip
termux-setup-storage
Распакуйте этот архив, например в ~/galaxysplit-ex5, затем:
cd ~/galaxysplit-ex5
python bridge.py --no-browser
Откройте напечатанный локальный URL в Chrome на этом телефоне.
Введите IP и порт уже открытого ADB на ГУ; при необходимости выполните сопряжение.

GalaxySplit EX5 Test 0.01. Android 11 / API 30. На реальном EX5 EM-i пока не проверено.
Системные файлы, root и постоянный автозапуск не изменяются.
Браузер общается только с локальным мостом; диагностика не отправляется на сайт.
ADB: Android Open Source Project, лицензии в tools/NOTICE.txt (Windows).
Мост написан для GalaxySplit; файлы стороннего EX5 EMI Split не используются.
