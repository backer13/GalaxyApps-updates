@echo off
cd /d "%~dp0"
"%~dp0GalaxySplit-Bridge.exe"
pause
