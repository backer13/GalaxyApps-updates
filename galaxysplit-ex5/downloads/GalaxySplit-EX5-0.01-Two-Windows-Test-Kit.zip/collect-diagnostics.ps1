param([string]$Serial)
$ErrorActionPreference = 'Stop'
$adb = Join-Path $PSScriptRoot 'tools/adb.exe'
. (Join-Path $PSScriptRoot 'adb-common.ps1')
if (!$Serial) {
    $connected = @(& $adb devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
    if ($connected.Count -ne 1) { throw 'Connect one authorized head unit or specify -Serial.' }
    $Serial = $connected[0]
}
$destination = Join-Path $PSScriptRoot ('diagnostics-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $destination | Out-Null
$reports = @{
    'helper.txt' = 'cat /data/local/tmp/galaxysplit-ex5-test.log'
    'tasks.txt' = 'dumpsys activity activities'
    'windows.txt' = 'dumpsys window windows'
    'firmware.txt' = 'getprop ro.build.fingerprint'
    'package.txt' = 'dumpsys package ru.galaxysplit.ex5test'
}
foreach ($entry in $reports.GetEnumerator()) {
    try { $text = Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments @('shell',$entry.Value) }
    catch { $text = $_.Exception.Message }
    $text | Set-Content (Join-Path $destination $entry.Key) -Encoding UTF8
}
try {
    Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments @('shell','screencap -p /sdcard/Download/galaxysplit-ex5-test.png') | Out-Null
    Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments @('pull','/sdcard/Download/galaxysplit-ex5-test.png',(Join-Path $destination 'screen.png')) | Out-Null
} catch { $_.Exception.Message | Set-Content (Join-Path $destination 'screenshot-error.txt') -Encoding UTF8 }
Write-Host "Saved: $destination"
Write-Host 'Logs can include names of running apps and screen content. Review before sharing.'
