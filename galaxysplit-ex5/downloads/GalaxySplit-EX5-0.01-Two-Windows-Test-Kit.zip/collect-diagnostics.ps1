param([string]$Serial)
$ErrorActionPreference = 'Stop'
$adb = Join-Path $PSScriptRoot 'tools/adb.exe'
if (!$Serial) {
    $connected = @(& $adb devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
    if ($connected.Count -ne 1) { throw 'Connect one authorized head unit or specify -Serial.' }
    $Serial = $connected[0]
}
$destination = Join-Path $PSScriptRoot ('diagnostics-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $destination | Out-Null
& $adb -s $Serial shell cat /data/local/tmp/galaxysplit-ex5-test.log 2>&1 | Set-Content (Join-Path $destination 'helper.txt') -Encoding UTF8
& $adb -s $Serial shell dumpsys activity activities 2>&1 | Set-Content (Join-Path $destination 'tasks.txt') -Encoding UTF8
& $adb -s $Serial shell dumpsys window windows 2>&1 | Set-Content (Join-Path $destination 'windows.txt') -Encoding UTF8
& $adb -s $Serial shell getprop ro.build.fingerprint 2>&1 | Set-Content (Join-Path $destination 'firmware.txt') -Encoding UTF8
& $adb -s $Serial shell dumpsys package ru.galaxysplit.ex5test 2>&1 | Set-Content (Join-Path $destination 'package.txt') -Encoding UTF8
& $adb -s $Serial shell screencap -p /sdcard/Download/galaxysplit-ex5-test.png
& $adb -s $Serial pull /sdcard/Download/galaxysplit-ex5-test.png (Join-Path $destination 'screen.png')
Write-Host "Saved: $destination"
Write-Host 'Logs can include names of running apps and screen content. Review before sharing.'
