# Windows PowerShell 5.1 and PowerShell 7: native output is always normalized to one string.
function Invoke-Ex5Adb {
    param([string]$Adb, [string]$DeviceSerial, [string[]]$Arguments)
    $previousPreference = $ErrorActionPreference
    try {
        # adb may announce daemon startup on stderr even when the command succeeds.
        $ErrorActionPreference = 'Continue'
        $lines = @(& $Adb -s $DeviceSerial @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousPreference
    }
    $text = [string](($lines | ForEach-Object { $_.ToString() }) -join "`n")
    if ($exitCode -ne 0) { throw ('ADB failed: ' + $text.Trim()) }
    return $text.Trim()
}

function ConvertTo-Ex5UserId {
    param([string]$Text)
    $values = @($Text -split '\r?\n' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d{1,4}$' })
    if ($values.Count -ne 1) { throw 'Cannot determine current Android user. Check ADB connection and collect diagnostics.' }
    return [string]$values[0]
}

function ConvertTo-Ex5ApkPath {
    param([string]$Text)
    $paths = @($Text -split '\r?\n' | ForEach-Object {
        $line = $_.Trim()
        if ($line.StartsWith('package:')) { $line.Substring(8).Trim() }
    })
    $basePaths = @($paths | Where-Object { $_.EndsWith('/base.apk') })
    if ($basePaths.Count -eq 1) { $selected = [string]$basePaths[0] }
    elseif ($paths.Count -eq 1) { $selected = [string]$paths[0] }
    else { throw 'Test APK not found or base APK is ambiguous. Install GalaxySplit EX5 Test using start-test.cmd first.' }
    if ($selected -notmatch '^/data/app/[A-Za-z0-9_=/+.~-]+\.apk$') {
        throw 'Unexpected test APK path. Save diagnostics and send them to the developer.'
    }
    return $selected
}
