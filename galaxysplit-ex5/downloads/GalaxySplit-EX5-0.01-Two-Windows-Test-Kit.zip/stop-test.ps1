param([string]$Serial)
$ErrorActionPreference = 'Stop'
$adb = Join-Path $PSScriptRoot 'tools/adb.exe'
if (!$Serial) {
    $connected = @(& $adb devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
    if ($connected.Count -ne 1) { throw 'Connect one authorized head unit or specify -Serial.' }
    $Serial = $connected[0]
}
$androidUserId = (& $adb -s $Serial shell am get-current-user).Trim()
if ($androidUserId -notmatch '^\d+$') { throw 'Cannot determine Android user.' }
$packagePath = ((& $adb -s $Serial shell pm path --user $androidUserId ru.galaxysplit.ex5test | Select-Object -First 1) -replace '^package:','').Trim()
if ($packagePath -notmatch '^/data/app/[A-Za-z0-9_=/+.~-]+\.apk$') { throw 'Test APK not found.' }
& $adb -s $Serial shell "CLASSPATH=$packagePath app_process /system/bin ru.galaxysplit.ex5test.helper.ControlCli shutdown"
if ($LASTEXITCODE -ne 0) { throw 'Could not stop helper. Save diagnostics; rebooting also removes this temporary helper.' }
Write-Host 'Test windows and temporary helper stopped. Apps were not force-stopped.'
