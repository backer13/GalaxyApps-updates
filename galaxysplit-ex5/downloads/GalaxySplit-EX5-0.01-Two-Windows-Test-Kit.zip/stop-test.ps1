param([string]$Serial)
$ErrorActionPreference = 'Stop'
$adb = Join-Path $PSScriptRoot 'tools/adb.exe'
. (Join-Path $PSScriptRoot 'adb-common.ps1')
if (!$Serial) {
    $connected = @(& $adb devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
    if ($connected.Count -ne 1) { throw 'Connect one authorized head unit or specify -Serial.' }
    $Serial = $connected[0]
}
$androidUserId = ConvertTo-Ex5UserId (Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments @('shell','am get-current-user'))
$packagePath = ConvertTo-Ex5ApkPath (Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments @('shell',"pm path --user $androidUserId ru.galaxysplit.ex5test"))
Write-Host (Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments @('shell',"CLASSPATH=$packagePath app_process /system/bin ru.galaxysplit.ex5test.helper.ControlCli shutdown"))
Write-Host 'Test windows and temporary helper stopped. Apps were not force-stopped.'
