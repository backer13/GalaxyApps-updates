﻿param([string]$Serial)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new()
$adb = Join-Path $PSScriptRoot 'tools/adb.exe'
$apk = Join-Path $PSScriptRoot 'GalaxySplit-EX5-0.02-Full-Interface-Preview.apk'
. (Join-Path $PSScriptRoot 'adb-common.ps1')
if (!(Test-Path -LiteralPath $adb) -or !(Test-Path -LiteralPath $apk)) { throw 'Unpack the entire archive before starting.' }
if (!$Serial) {
    $connected = @(& $adb devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
    if ($connected.Count -ne 1) { & $adb devices -l; throw 'Connect and authorize one head unit, or run start-test.ps1 -Serial DEVICE_ID.' }
    $Serial = $connected[0]
}
function Invoke-TestAdb {
    param([string[]]$Arguments)
    return Invoke-Ex5Adb -Adb $adb -DeviceSerial $Serial -Arguments $Arguments
}
$sdk = Invoke-TestAdb -Arguments @('shell','getprop ro.build.version.sdk')
if ($sdk -ne '30') { throw "This test supports Android 11 / API 30 only. Found: $sdk" }
Write-Host 'GalaxySplit EX5 Preview 0.02 - full interface'
Write-Host 'Park the vehicle before testing. Close any other split application.'
Write-Host (Invoke-TestAdb -Arguments @('shell','getprop ro.product.model'))
Write-Host (Invoke-TestAdb -Arguments @('install','-r',$apk))
Write-Host (Invoke-TestAdb -Arguments @('shell', 'appops set --user current ru.galaxysplit.ex5test SYSTEM_ALERT_WINDOW allow'))
$androidUserId = ConvertTo-Ex5UserId (Invoke-TestAdb -Arguments @('shell','am get-current-user'))
Write-Host (Invoke-TestAdb -Arguments @('shell',"am start --user $androidUserId -n ru.galaxysplit.ex5test/.TestActivity"))
Start-Sleep -Seconds 2
$connectionKey = Invoke-TestAdb -Arguments @('shell',"run-as ru.galaxysplit.ex5test --user $androidUserId cat files/helper-token")
if ($connectionKey -notmatch '^[a-f0-9]{64}$') { throw 'Cannot read the private helper connection key.' }
$packageInfo = Invoke-TestAdb -Arguments @('shell',"pm list packages -U --user $androidUserId ru.galaxysplit.ex5test")
if ($packageInfo -notmatch 'package:ru\.galaxysplit\.ex5test\s+uid:(\d+)') { throw "Cannot determine test app UID: $packageInfo" }
$testAppUid = $Matches[1]
$packagePath = ConvertTo-Ex5ApkPath (Invoke-TestAdb -Arguments @('shell',"pm path --user $androidUserId ru.galaxysplit.ex5test"))
# A previous test helper is stopped through its narrow local protocol, never by killing apps.
& $adb -s $Serial shell "CLASSPATH=$packagePath app_process /system/bin ru.galaxysplit.ex5test.helper.ControlCli shutdown 2>/dev/null" | Out-Null
Start-Sleep -Milliseconds 800
Write-Host (Invoke-TestAdb -Arguments @('shell',"CLASSPATH=$packagePath nohup app_process /system/bin ru.galaxysplit.ex5test.helper.Helper $testAppUid $androidUserId $connectionKey > /data/local/tmp/galaxysplit-ex5-test.log 2>&1 < /dev/null &"))
Start-Sleep -Seconds 2
$probe = Invoke-TestAdb -Arguments @('shell',"CLASSPATH=$packagePath app_process /system/bin ru.galaxysplit.ex5test.helper.ControlCli status")
Write-Host $probe
Write-Host (Invoke-TestAdb -Arguments @('shell',"am start --user $androidUserId -n ru.galaxysplit.ex5test/.TestActivity"))
Write-Host 'Ready. Create a preset or choose one-time launch in GalaxySplit.'
Write-Host 'After testing run collect-diagnostics.cmd on this PC.'
